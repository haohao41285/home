<?php $__env->startSection('notes'); ?>
<div class="addNote col-md-12" id="add">
	<h4 class="text-center">Add Note</h4>
	<table class="table table-hover table-bordered  table-responsive">
		<caption>Add Note</caption>
		<tbody>
			<form action="<?php echo e(route('admin.addNote')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<tr>
					<td>Tittle</td>
					<td><input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder=""></td>
				</tr>
				<tr>
					<td>Content</td>
					<td><textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Add" class="btn btn-primary btn-sm"></td>
				</tr>
			</form>
		</tbody>
	</table>
</div>
<script type="text/javascript">
	$(function(){
		$(".add").on('click',function(){
			$(".addNote").slideToggle(1000);
		});
	});
</script>
<div class="stories">
<h4 class="text-center">Bảng Notes</h4>
<p class="text-center">Có tất cả: <span><?php echo e($count); ?></span> Notes</p>
<table class="table table-hover table-bordered  table-dark table-responsive">
	<caption>Bảng Notes</caption>
	<thead>
		<tr>
			<th>Stt</th>
			<th>Id</th>
			<th>Title</th>
			<th>Content</th>
			<th>Date</th>
			<th>Functions</th>
		</tr>
	</thead>
	<tbody>
		<?php $stt=1; ?>
		<?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr class="note<?php echo e($note->id); ?>"  scope="row">
			<td scope="col"><?php echo e($stt); ?></td>
			<td scope="col"><?php echo e($note->id); ?></td>
			<td scope="col"><?php echo e($note->title); ?></td>
			<td scope="col"><?php echo e(shortcut($note->content,0,80)); ?></td>
			<td scope="col"><?php echo e($note->created_at); ?></td>
			<td scope="col">
				<a href="#add" class="add" title="Add"><i class="fa fa-plus" aira-hidden="true"></i></a>&nbsp
				<a class="delete<?php echo e($note->id); ?>" title="Delete"><i class="fa fa-trash-o" aira-hidden="true"></i></a>&nbsp
				<a href="<?php echo e(route('editNote',$note->id)); ?>" title="Fix"><i class="fa fa-pencil" aira-hidden="true"></i></a>
				<script>
					$(function(){
						$(".delete<?php echo e($note->id); ?>").on('click',function(){
							var id=<?php echo e($note->id); ?>;
							if(confirm('Xóa mục này')==true){
									$.ajax({
									type:'get',
									dataType:'html',
									url:'<?php echo url('manager/deleteNote'); ?>/'+id,
									data:"id="+id,
									success:function(response){
										//console.log(response);
										$(".note<?php echo e($note->id); ?>").hide(100);
										alert('Đã xóa');
									}
								});
							}
							else {
								return false;
							}
							
						});
					});
				</script>
			</td>
			
		</tr>
		<?php  $stt++; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>