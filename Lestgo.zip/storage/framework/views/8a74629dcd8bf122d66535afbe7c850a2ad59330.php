<?php $__env->startSection('user'); ?>
<div class="stories">
<h4 class="text-center">Bảng  người dùng</h4>
<p class="text-center">Có tất cả: <span><?php echo e($count); ?></span> user</p>
<table class="table table-hover table-bordered table-striped table-dark table-responsive">
	<caption>Bảng Người dùng</caption>
	<thead>
		<tr>
			<th>Stt</th>
			<th>Id</th>
			<th>name</th>
			<th>Email</th>
			<th>Remember_token</th>
			<th>Created_at</th>
			<th>Updated_at</th>
		</tr>
	</thead>
	<tbody>
		<?php $stt=1; ?>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr   scope="row">
			<td scope="col"><?php echo e($stt); ?></td>
			<td scope="col"><?php echo e($user->id); ?></td>
			<td scope="col"><?php echo e($user->name); ?></td>
			<td scope="col"><?php echo e($user->email); ?></td>
			<td scope="col"><?php echo e($user->remember_token); ?></td>
			<td scope="col"><?php echo e($user->created_at); ?></td>
			<td scope="col"><?php echo e($user->updated_at); ?></td>
		</tr>
		<?php  $stt++; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>