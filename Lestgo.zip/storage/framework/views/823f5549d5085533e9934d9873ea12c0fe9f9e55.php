<ul>
	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('detail',str_replace(' ','-',$result->title))); ?>" title=""><li><?php echo e($result->title); ?></li></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<ul>
	<?php $__currentLoopData = $result1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('list',str_replace(' ','-',$result1->name))); ?>" title=""><li><?php echo e($result1->name); ?></li></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>