<?php $__env->startSection('add'); ?>
<table class="table table-hover table-bordered  tabel-responsive">
	<caption>Add Story</caption>

	<tbody>
		<form action="<?php echo e(route('admin.postAdd')); ?>" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

		<tr>
			<td>Title</td>
			<td><input class="form-control" type="text" name="title" value="<?php echo e(old('title')); ?>"></td>
		</tr>
		<tr>
			<td>Content</td>
			<td><textarea name="content" class="form-control" value="<?php echo e(old('content')); ?>" rows="5"></textarea>
				<script>
					CKEDITOR.replace('content')
				</script>
			</td>
		</tr>
		<tr>
			<td>Image</td>
			<td>
				<input type="file" value="<?php echo e(old('img')); ?>" class="btn btn-primary btn-sm" name="img">
			</td>
		</tr>
		<tr>
			<td>Gallery</td>
			<td><select class="form-control w-25" name="id_gallery">
				<?php $galleries=DB::table('galleries')->select('name','id')->get(); ?>
				<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($gallery->id); ?>"><?php echo e($gallery->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select></td>
		</tr>
		<tr>
			<td>Trend</td>
			<td>
				<input type="radio"  name="trend"  value="1">Yes<br>
		</tr>
		<tr>
			<td>Hot</td>
			<td>
				<input type="radio" name="hot"  value="1">Yes<br>
			</td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" class="btn btn-sm btn-primary" value="Add"></td>
		</tr>
	</form>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>