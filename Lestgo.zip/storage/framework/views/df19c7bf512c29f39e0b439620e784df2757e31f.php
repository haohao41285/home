<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/add.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('detail'); ?>
<style type="text/css" media="screen">
	.detail-left>h5{
		text-align: center;
		border-bottom: 1px #c7cbcf dotted;
		padding-bottom: 5px;
		margin-bottom: 10px;
	}
</style>
<input class="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
<input type="hidden" class="id_gallery" name="id_gallery" value="<?php echo e($news->id_gallery); ?>">
<div class=" container box my-5">
	<div class="row">
		
		<div class="col-md-6 offset-md-1 detail-left">
			
			<h3><?php echo e($news->title); ?></h3>
			<img class="py-2 img img-responsive" src="<?php echo e(asset($news->img)); ?>"><br><br>
			<?php echo $news->content; ?>

			
			<div class="clearfix end"></div>
			<div class="share px-2">
				<h4  class="border px-3 font-italic box shareYou" onclick="register()">Share your interesting experiences about this place at here</h4>
				<div class="shareStory py-5"></div>
			</div>
			
		</div>
		
		<div class="col-md-3 offset-md-1  detail-right" >
			<h3 class="text-center">The Same Region</h3>
			<hr class="border">
			<div class="scroll-region mb-3">
				<?php $__currentLoopData = $new_others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row detail-right-mini py-2 px-2">
						<div class="col-md-4 col-4">
							<img src="<?php echo e(asset($new_other->img)); ?>" alt="">
						</div>
						<div class="col-md-8 col-8">
							<a href="<?php echo e(route('detail',str_replace(' ','-',$new_other->title))); ?>" title="">
								<p class="pl-1"><?php shortcut($new_other->title,0,50); ?></p>
							</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<h3 class="text-center">Regions</h3>
			<hr class="border">
			<div class="row gallery-info">
		<?php $lists=DB::table('galleries')->select('id','name','img')->get(); ?>
		<?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4 col-6 gallery-grids">
				<div class="galry-grid grid-top-rgt mb-0">
					<a href="<?php echo e(route('list',str_replace(' ','-',$list->name))); ?>" class="showcase" data-rel="lightcase:myCollection:slideshow" title="Travel Destinations">
						<img src="<?php echo e(asset($list->img)); ?>" alt="" class="img-responsive zoom-img">
						<div class="w3agile-text w3agile-text-small1">
							<h5 class="name-region"><?php echo e($list->name); ?></h5>
						</div>
					</a>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>