<?php $__env->startSection('view'); ?>
<div class="container">
	<div class="border  mb-3">
		<h4><?php echo e($stories_user->title); ?></h4>
		<img class="img-responsive img" style="max-height: 500px;max-width:
		500px;" src="<?php echo e(asset($stories_user->img)); ?>"" alt="">
		<p><b><?php echo(DB::table('galleries')->find($stories_user->id_gallery)->name); ?></b></p>
		<p><?php echo $stories_user->content; ?></p>
	<div>
	<?php $info_user=DB::table('users')->find($stories_user->id_user); ?>

	<div class="border text-center w-50 mx-auto">
		<h4>User's Information</h4>
		<hr>
		<p>Name: <b><?php echo e($info_user->name); ?></b></p>
		<p>Email: <b><?php echo e($info_user->email); ?></b></p>
		<p>Country: <b><?php echo e($info_user->country); ?></b></p>
    </div>
	<button class="btn btn-primary " id="post">Post</button><span class="posted"></span>
</div>
<script>
	$(function(){
		$("#post").on('click',function(){
			var id=<?php echo e($stories_user->id); ?>;
			$.ajax({
				type:'get',
				dataType:'html',
				url:'<?php echo url('manager/post'); ?>/'+id,
				data:"id="+id+"&name="+name,
				success:function(response){
					console.log(response);
					$(".posted").text("Đã Đăng");
				}
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>