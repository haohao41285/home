<?php $__env->startSection('stories_user'); ?>
<div class="stories">
<h4 class="text-center">Bảng Stories người dùng</h4>
<p class="text-center">Có tất cả: <span><?php echo e($count); ?></span> stories</p>
<table class="table table-hover table-bordered table-striped table-dark table-responsive">
	<caption>Bảng Stories</caption>
	<thead>
		<tr>
			<th>Stt</th>
			<th>Id</th>
			<th>Title</th>
			<th>Content</th>
			<th>Post</th>
			<th>Img</th>
			<th>Gallery</th>
			<th>Date</th>
		</tr>
	</thead>
	<tbody>
		<?php $stt=1; ?>
		<?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr class="story<?php echo e($story->id); ?>"  scope="row">
			<td scope="col"><?php echo e($stt); ?></td>
			<td scope="col"><?php echo e($story->id); ?></td>
			<td scope="col"><?php echo e($story->title); ?></td>
			<td scope="col"><?php echo e(shortcut($story->content,0,80)); ?></td>
			<td scope="col">
				<a href="<?php echo e(route('admin.view',$story->id)); ?>" title="">View</a><br>

				<p style="color: red"><?php  if($story->post==1)echo "Posted";else " "; ?></p>
			</td>
			<td><img class="img-responsive" src="<?php echo e(asset($story->img)); ?>"></td>
			<td><a href="<?php echo e(route('admin.gallery',$story->id_gallery)); ?>" title=""><?php echo(DB::table('galleries')->find($story->id_gallery)->name); ?></a></td>
			<td><?php echo e($story->created_at); ?></td>
		</tr>
		<?php  $stt++; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php echo e($stories->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>