<?php $__env->startSection('shareStory'); ?>
<style type="text/css" media="screen">
	span{color:white;background-color: red}
</style>
<h3 class="heading text-center">Write your story about <?php $idGallery=DB::table('galleries')->select('id','name')->where('id',$id_gallery)->first(); ?><?php echo e($idGallery->name); ?></h3>
<?php 
if(isset($notice1)) echo "<p style='color:red;text-align:center'><span><i>".$notice1."</span></i></p>";
?>


<table class="table table-responsive table-hover">
	<thead>
	</thead>
	<tbody>
		<form action="<?php echo e(route('postStoryUser')); ?>" method="post" enctype="multipart/form-data">
			<input type="hidden" value="<?php echo e($idGallery->id); ?>" name="id_gallery">
			<input type="hidden" value="<?php echo e($id); ?>" name="id_user">
			<input type="hidden" value="<?php echo e($name); ?>" name="name">
			<?php echo e(csrf_field()); ?>

			<tr>
				<td>TITLE</td>
				<td><input type="text" class="form-control" name="title"  value="<?php echo e(old('title')); ?>"><br><span><?php echo e($errors->first('title')); ?></span></td>
			</tr>
			<tr>
				<td>AVATAR OF THE STORY</td>
				<td><input type="file" name="img" required><br><span><?php echo e($errors->first('img')); ?></span></td>
			</tr>
			<tr>
				<td>CONTENT<br><span>About 1000 ~ 3000 characters.</span><br><span> If your story longer, you can devide into other part.</span></td>
				<td><textarea name="content" id="content" class="form-control" required ><?php echo e(old('content')); ?></textarea><span><?php echo e($errors->first('content')); ?></span>
					<script>
						CKEDITOR.replace('content');
					</script>
				</td>
			</tr>
			<tr>
				<td></td>
				<td> <input type="submit" value="Post" class="btn btn-sm nut"></td>
			</tr>
		</form>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>