<?php $__env->startSection('notes'); ?>
<?php $d="active"; ?>
<div class="container box">
	<h3 class="heading text-center my-2">Notes</h3>
	<p class="text-center font-weight-light font-italic">Some notes maybe you need when wanna explore VietNam.</p>
	<hr class="border w-25">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>