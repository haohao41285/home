<?php $__env->startSection('editNote'); ?>
<div class="col-md-12">
	<table class="table table-responsive table-hover table-bordered">
		<caption>Edit Note</caption>
		<tbody>
			<form action="<?php echo e(route('admin.postEditNote',$notes['id'])); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<tr>
					<td>Title</td>
					<td><input type="text" class="form-control form-sm" name="title" value="<?php echo e($notes['title']); ?>"></td>
				</tr>
				<tr>
					<td>Content</td>
					<td><textarea name="content" class="form-control"><?php echo e($notes['content']); ?></textarea>
						<script>
							CKEDITOR.replace('content');
						</script>
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" class="btn btn-primary btn-sm" value="Edit"></td>
				</tr>
			</form>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>