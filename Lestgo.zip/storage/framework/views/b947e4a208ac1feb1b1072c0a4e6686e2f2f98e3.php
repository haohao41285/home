<?php $__env->startSection('editGallery'); ?>
<div class=" col-md-12">
<h4 class="text-center">Edit Regions</h4>
	<table class="table table-hover table-bordered  tabel-responsive">
		<caption>Edit Region</caption>
		<tbody>

			<form action="<?php echo e(route('admin.postEditGallery',$galleries['id'])); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<tr>
					<td>Name</td>
					<td><input type="text" class="form-control" name="name" value="<?php echo e($galleries['name']); ?>"></td>
				</tr>
				<tr>
					<td>Description</td>
					<td><textarea name="describe" id="describe" class="form-control" rows="5"><?php echo e($galleries['describe']); ?></textarea>
					</td>
				</tr>
				<tr>
					<td>Avatar</td>
					<td>
						<img src="<?php echo e(asset($galleries['img'])); ?>" class="img-gallery img-ressponsive" alt=""><br><br>
						<input type="file" class="btn btn-primary btn-sm" name="img" value="<?php echo e($galleries['img']); ?>"></td>
				</tr>
				<tr>
					<td>Wiki</td>
					<td><input type="text" class="form-control" name="wiki" value="<?php echo e($galleries['wiki']); ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" class="btn btn-primary btn-sm" value="Edit"></td>
				</tr>
			</form>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>