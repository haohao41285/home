<?php $__env->startSection('gallery'); ?>
<div class="gallery py-5">
	<div class="container box py-sm-3">
		<h3 class="heading text-center mb-md-2">Our Gallery</h3>
		<p class="text-center font-italic" style="color:red">Anywhere has interesting things. Let's go!</p>
		<hr class="border w-25">
		<div class="row gallery-info">
			<div class="col-md-4 gallery-grids">
				<?php $__currentLoopData = $galleries1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="galry-grid grid-top-rgt px-1 py-1">
					<a href="<?php echo e(route('list',str_replace(' ','-',$gallery1->name))); ?>" class="showcase" data-rel="lightcase:myCollection:slideshow" title="Travel Destinations">
						<img src="<?php echo e($gallery1->img); ?>" alt="" class="img-responsive zoom-img">
						<div class="w3agile-text w3agile-text-small1">
							<h5><?php echo e($gallery1->name); ?></h5>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-4 gallery-grids">
				<?php $__currentLoopData = $galleries3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="galry-grid grid-top-rgt px-1 py-1">
					<a href="<?php echo e(route('list',str_replace(' ','-',$gallery3->name))); ?>" class="showcase" data-rel="lightcase:myCollection:slideshow" title="Travel Destinations">
						<img src="<?php echo e($gallery3->img); ?>" alt="" class="img-responsive zoom-img">
						<div class="w3agile-text w3agile-text-small1">
							<h5><?php echo e($gallery3->name); ?></h5>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-4  gallery-grids">
				
			    <?php $__currentLoopData = $galleries2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="galry-grid grid-top-rgt px-1 py-1">
					<a href="<?php echo e(route('list',str_replace(' ','-',$gallery2->name))); ?>" class="showcase" data-rel="lightcase:myCollection:slideshow" title="Travel Destinations">
						<img src="<?php echo e($gallery2->img); ?>" alt="" class="img-responsive zoom-img">
						<div class="w3agile-text w3agile-text-small1">
							<h5><?php echo e($gallery2->name); ?></h5>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="clearfix"> </div>
		</div> 
	</div> 
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>