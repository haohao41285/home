<?php $__env->startSection('stories'); ?>
<div class="stories">
<h4 class="text-center">Bảng Stories</h4>
<p class="text-center">Có tất cả: <span><?php echo e($count); ?></span> stories</p>
<table class="table table-hover table-bordered table-striped table-dark table-responsive">
	<caption>Bảng Stories</caption>
	<thead>
		<tr>
			<th>Stt</th>
			<th>Id</th>
			<th>Title</th>
			<th>Content</th>
			<th>Functions</th>
			<th>Img</th>
			<th>Gallery</th>
			<th>Date</th>
		</tr>
	</thead>
	<tbody>
		<?php $stt=1; ?>
		<?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr class="story<?php echo e($story->id); ?>"  scope="row">
			<td scope="col"><?php echo e($stt); ?></td>
			<td scope="col"><?php echo e($story->id); ?></td>
			<td scope="col"><?php echo e($story->title); ?> <?php echo ($story->hot==1)?"<span style='color:red;font-weight: bold'>Hot</span>":""; ?> <?php echo ($story->trend==1)?"<span style='color:red;font-weight: bold'>Trend</span>":""; ?></td>
			<td scope="col"><?php echo e(shortcut($story->content,0,80)); ?></td>
			<td scope="col">
				<a href="<?php echo e(route('add')); ?>" title="Add"><i class="fa fa-plus" aira-hidden="true"></i></a>&nbsp
				<a  title="Delete" class="delete<?php echo e($story->id); ?>" ><i class="fa fa-trash-o" aira-hidden="true"></i></a>&nbsp
				<a href="<?php echo e(route('admin.edit',$story->id)); ?>" title="Fix"><i class="fa fa-pencil" aira-hidden="true"></i></a>
				<script>
					$(function(){
						$(".delete<?php echo e($story->id); ?>").on('click',function(){
							var id=<?php echo e($story->id); ?>;
							if(confirm('Xóa mục này?')==true)
							{
									$.ajax({
									type:'get',
									dataType:'html',
									url:'<?php echo url('manager/delete'); ?>/'+id,
									data:'id='+id,
									success:function(response){
										console.log(response);
										$(".story<?php echo e($story->id); ?>").hide(0);
										alert('Đã xóa một mục!');
									}
								});
							}
							else {
								return false;
							}
							
						});
					});
				</script>
			</td>
			<td><img class="img-responsive" src="<?php echo e(asset($story->img)); ?>"></td>
			<td><a href="<?php echo e(route('admin.gallery',$story->id_gallery)); ?>" title=""><?php echo(DB::table('galleries')->find($story->id_gallery)->name);?></a></td>
			<td><?php echo e($story->created_at); ?></td>
		</tr>
		<?php  $stt++; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php echo e($stories->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>