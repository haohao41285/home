<?php $__env->startSection('register'); ?>
<div class="col-md-4 offset-md-4">
	<h4 class="text-center text-white">INFORMATION REGISTER</h4>
	<form action="<?php echo e(route('registerAdmin')); ?>" method="post" accept-charset="utf-8">
		<input type="hidden" value="<?php echo e(csrf_token()); ?>" name="token">
		<?php echo e(csrf_field()); ?>

		<input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name" required><br>
		<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required><br>
		<input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Phone" required><br>
		<input type="password" class="form-control"  name="password" value="" placeholder="Password" required><br>
		<input type="submit" class="btn btn-sm btn-primary"  value="Register">
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>