<?php $__env->startSection('search'); ?>
<script>
	$(function()
	{
		$(window).load(function(){
			$(".page-link").removeAttr('href');
		});
	});
$(function()
	{
		$(".page-link").on("click",function(){
			$(this).removeAttr('href');
			var t=$(this).text();
			$.ajax({
				type:'get',
				dataType:'html',
				url:'<?php echo url('next'); ?>',
				data:"id="+t,
				success:function(response){
					//console.log(response);
					$("#content_stories").html(response);
					$(".page-link").removeAttr('href');
				}
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stories'); ?>
<!-- /stories -->
<?php $b="active"; ?>
<section class="featured_services py-5">
	<div class="container py-sm-3 box">
		<h3 class="heading text-center mb-sm-5 mb-2">Hot Places
			<hr class="w-25 border"></h3>
			<div class="row agile_inner_info">
				<?php $__currentLoopData = $hots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-3 col-sm-6  w3_agile_services_grid px-2">
				<div class="agile_services_grid">
					<div class="hover06 column">
						<div>
							<figure><img src="<?php echo e(asset($hot->img)); ?>" alt=" " class="img-responsive"></figure>
						</div>
					</div>
				</div>
				<h4><a href="<?php echo e(route('detail',str_replace(' ','-',$hot->title))); ?>" title=""><?php echo e($hot->title); ?></a></h4>
				<p><?php echo shortcut($hot->content,0,99); ?>...</p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<h3 class="heading text-center mb-sm-5 mb-2">Our Stories
			<hr class="border w-25"></h3>
		<div class="row agile_inner_info" id="content_stories">
			<?php $__currentLoopData = $storiess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-3 col-sm-6  w3_agile_services_grid px-2">
				<div class="agile_services_grid">
					<div class="hover06 column">
						<div>
							<figure><img src="<?php echo e($stories->img); ?>" alt=" " class="img-responsive"></figure>
						</div>
					</div>
				</div>
				<h4><a href="<?php echo e(route('detail',str_replace(' ','-',$stories->title))); ?>" title=""><?php echo e($stories->title); ?></a></h4>
				<p><?php echo shortcut($stories->content,0,90); ?>...</p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="container mt-3"><?php echo e($storiess->links()); ?></div>
		</div>
		
	</div>
</section>
<!-- //stories -->	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>