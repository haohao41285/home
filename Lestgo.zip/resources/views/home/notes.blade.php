@extends('home.master')
@section('notes')
<?php $d="active"; ?>
<div class="container box">
	<h3 class="heading text-center my-2">Notes</h3>
	<p class="text-center font-weight-light font-italic">Some notes maybe you need when wanna explore VietNam.</p>
	<hr class="border w-25">
</div>
@endsection